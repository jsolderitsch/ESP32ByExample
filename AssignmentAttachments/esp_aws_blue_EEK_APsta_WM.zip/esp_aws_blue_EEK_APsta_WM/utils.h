#include "esp32-hal.h"
#include <Arduino_BuiltIn.h>

#include "certs.h"
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <ArduinoJson.h>
#include "WiFi.h"
#include <WiFiManager.h>  // https://github.com/tzapu/WiFiManager
#include <Adafruit_SSD1306.h>
#include <Adafruit_Sensor.h>
#include "Wire.h"
#include <MPU6050_light.h>
#include <EasyButton.h>

#define AWS_IOT_PUBLISH_TOPIC "esp32/blue"
#define AWS_IOT_SUBSCRIBE_TOPIC "esp32/red"

// LED configs
#define BLUE 27
#define YELLOW 25
#define TOP_GREEN 33
#define TOP_RED 12
#define BOTTOM_RED 26
#define BOTTOM_GREEN 4
// Arduino pins where the buttons are connected to
#define BOTTOM_RIGHT 21
#define BOTTOM_LEFT 16
#define TOP_RIGHT 32
#define TOP_LEFT 15
#define MIDDLE_RIGHT 14
#define MIDDLE_LEFT 17

const char* ssid = "EEK-CCDB";
const char* password = "EEK-TEST";

MPU6050 mpu(Wire);
Adafruit_SSD1306 display = Adafruit_SSD1306(128, 32, &Wire);
WiFiClientSecure net = WiFiClientSecure();
PubSubClient client(net);
String macAddress = WiFi.macAddress();

int Roll;
int Pitch;
int Temp;

// Button1
EasyButton button1(BOTTOM_RIGHT);
// Button2
EasyButton button2(BOTTOM_LEFT);
// Button3
EasyButton button3(TOP_RIGHT);
// Button4
EasyButton button4(TOP_LEFT);
// Button5
EasyButton button5(MIDDLE_LEFT);
// Button6
EasyButton button6(MIDDLE_RIGHT);

void toggle_led(int ledToToggle) {
  // Toggle the state of the LED pin (write the NOT of the current state to the LED pin)
  digitalWrite(ledToToggle, !digitalRead(ledToToggle));
  delay(2000);
  digitalWrite(ledToToggle, !digitalRead(ledToToggle));
}

void publishMessage(String metricsKey, int metricsValue) {
  StaticJsonDocument<200> doc;
  doc["MAC"] = macAddress;
  doc[metricsKey] = metricsValue;

  char jsonBuffer[512];
  serializeJson(doc, jsonBuffer);
  Serial.print("outgoing: ");
  Serial.println(jsonBuffer);

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("outgoing:");
  display.println(jsonBuffer);
  display.display();
  toggle_led(BLUE);

  client.publish(AWS_IOT_PUBLISH_TOPIC, jsonBuffer);
}

// Callback function to be called when button1 is pressed
void onButton1Pressed() {
  display.println("Bottom Right Button Pressed");
  display.display();
  publishMessage("buttonPin", BOTTOM_RIGHT);
  toggle_led(BOTTOM_GREEN);
}

// Callback function to be called when button2 is pressed
void onButton2Pressed() {
  display.println("Bottom Left Button Pressed");
  display.display();
  publishMessage("buttonPin", BOTTOM_LEFT);
  toggle_led(BOTTOM_RED);
}


// Callback function to be called when button3 is pressed
void onButton3Pressed() {
  display.println("Top Right Button Pressed");
  display.display();
//  publish message here like buttons 1 and 2
}

// Callback function to be called when button4 is pressed
void onButton4Pressed() {
  display.println("Top Left Button Pressed");
  display.display();
//  publish message here like buttons 1 and 2
}

// Callback function to be called when button5 is pressed
void onButton5Pressed() {
  display.println("Middle Left Button Pressed");
  display.display();
  // replace this publish with publishing current MPU temp
  publishMessage("buttonPin", MIDDLE_LEFT);
}

// Callback function to be called when button6 is pressed
void onButton6Pressed() {
  display.println("MPU Button Pressed");
  display.display();
  publishMessage("pitch", Pitch);
  publishMessage("roll", Roll);
}

void messageHandler(char* topic, byte* payload, unsigned int length) {
  Serial.print("incoming: ");
  Serial.println(topic);

  StaticJsonDocument<200> doc;
  deserializeJson(doc, payload);
  char jsonBuffer[512];
  serializeJson(doc, jsonBuffer);
  Serial.println(jsonBuffer);
  String jsonString = String(jsonBuffer);
  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("incoming:");
  display.println(topic);
  display.println(jsonBuffer);
  display.display();
  toggle_led(YELLOW);
  if (jsonString.indexOf("Hello") >= 0) {
    toggle_led(TOP_RED);
    toggle_led(BLUE);
    toggle_led(TOP_GREEN);
  }
}


void connectAWS() {

  WiFi.mode(WIFI_AP_STA);  // explicitly set mode, esp defaults to STA+AP

  WiFiManager wm;
  // reset settings - wipe stored credentials for testing
  // these are stored by the esp library
  // wm.resetSettings();
  bool res;
  // res = wm.autoConnect(); // auto generated AP name from chipid
  // res = wm.autoConnect("AutoConnectAP"); // anonymous ap
  res = wm.autoConnect(ssid, password);  // password protected ap

  if (!res) {
    Serial.println("Failed to connect");
    // ESP.restart();
  } else {
    //if you get here you have connected to the WiFi
    Serial.println("connected...yeey :)");
    Serial.print("\n[+] Connected to WiFi network with local IP : ");
    Serial.println(WiFi.localIP()); /*Printing IP address of Connected network*/
  }

  Serial.println("\n[*] Creating ESP32 AP");
  WiFi.softAP(ssid, password);  // ESP-32 as access point

  Serial.print("[+] AP Created with IP Gateway ");
  Serial.println(WiFi.softAPIP()); /*Printing the AP IP address*/
  Serial.print("ESP Board MAC Address:  ");
  Serial.println(WiFi.macAddress());
  Serial.print("Soft-AP IP address = ");
  Serial.println(WiFi.softAPIP());

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("Soft-AP IP address:");
  display.println(WiFi.softAPIP());
  display.println("Waiting...");
  display.display();

  // Configure WiFiClientSecure to use the AWS IoT device credentials
  net.setCACert(AWS_CERT_CA);
  net.setCertificate(AWS_CERT_CRT);
  net.setPrivateKey(AWS_CERT_PRIVATE);

  // Connect to the MQTT broker on the AWS endpoint we defined earlier
  client.setServer(AWS_IOT_ENDPOINT, 8883);

  // Create a message handler
  client.setCallback(messageHandler);

  Serial.println("Connecting to AWS IOT");

  while (!client.connect(THINGNAME)) {
    Serial.print(".");
    delay(100);
  }

  if (!client.connected()) {
    Serial.println("AWS IoT Timeout!");
    return;
  }

  client.subscribe(AWS_IOT_SUBSCRIBE_TOPIC);

  Serial.println("AWS IoT Connected!");
}
